module.exports = {
  purge: ['./public/**/*.html', './src/**/*.vue'],
  darkMode: false,
  theme: {
    extend: {}
  },
  variants: {
    extend: {}
  },
  plugins: []
}
